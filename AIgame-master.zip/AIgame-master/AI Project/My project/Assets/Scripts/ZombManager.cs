using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class ZombManager : MonoBehaviour
{
    public IdleState starting;

    [SerializeField] private State currentState;

    [Header("Current Target")]
    public PlayerMovement currentTarget;
    public float DistFromTarget;

    [Header("Animator")]
    public Animator animator;


    //the inbuilt unity nav mesh agent thats been attached to the zombie
    [Header("Navmesh")]
    public NavMeshAgent zombNMAgent;

    [Header("Rigidybody")]
    public Rigidbody zombieRB;

    [Header("Locomotion")]
    public float rotationSpeed = 5;

    [Header("Attack")]
    public float minAttackDist = 3;

    private void Awake()
    {
        currentState = starting;
        zombNMAgent = GetComponentInChildren<NavMeshAgent>();
        animator = GetComponent<Animator>();
        zombieRB = GetComponent<Rigidbody>();
    }

    private void FixedUpdate()
    {
        Handler();
    }

    //calculates the distance between the zombie and the player
    private void Update()
    {
        zombNMAgent.transform.localPosition = Vector3.zero;

        if (currentTarget != null)
        {
            DistFromTarget = Vector3.Distance(currentTarget.transform.position, transform.position);
        }
    }
    private void Handler()
    {
        State nextState;

        if (currentState != null)

        {
            nextState = currentState.Tick(this);

            if (nextState != null)
            {
                currentState = nextState;
            }

        }

    }
}

