using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class State : MonoBehaviour
{
   //all other scripts overwrite this script, causing this to be the active state.
    public virtual State Tick(ZombManager zombManager)
    {

            Debug.Log("Running");
            return this;
        
    }
}
