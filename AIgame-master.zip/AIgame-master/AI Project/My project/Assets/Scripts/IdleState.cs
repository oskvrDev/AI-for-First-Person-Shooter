using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IdleState : State
{
    ChaseState chaseState;

    [SerializeField] LayerMask detectionLayer;
    [SerializeField] float detectionRadius = 5;

    //changes so that raycast dont start from the floor
    [SerializeField] float characterHeight = 2f;
    //ignores its own collider for the raycast
    [SerializeField] LayerMask ignoreSelfCollider;

    //FOV radius for the zombie

    [SerializeField] float minDetectRadAngle = -100f;
    [SerializeField] float maxDetectRadAngle = 180f;

    private void Awake()
    {
        chaseState = GetComponent<ChaseState>();
    }

    public override State Tick(ZombManager zombManager)
    {
        //if the currenttarget is true then it will go to the chase state
        if (zombManager.currentTarget !=null)
        {
            Debug.Log("Target Found");
            return chaseState;
        }
        //if no target then it will idle
        else
        {
            FindTarget(zombManager);
            Debug.Log("No Target");
            return this;
        }
    }

    private void FindTarget(ZombManager zombManager)
    {
        //searching colliders within a certain radius

        Collider[] colliders = Physics.OverlapSphere(transform.position, detectionRadius, detectionLayer);

        Debug.Log("Checking for Colliders");


        for (int i = 0; i < colliders.Length; i++)
        {
            PlayerMovement player = colliders[i].transform.GetComponent<PlayerMovement>();
            
            //if the player script is detected, check for line of sight

            if (player != null)
            {
                //player is visble and in line of sight of the zombie
                Debug.Log("Found Player");

                
                Vector3 targetDirection = transform.position - player.transform.position;
                float viewAngle = Vector3.Angle(targetDirection, transform.forward);
                Debug.Log("VIEW ANG = " + viewAngle);
                //if the player is within the zombie field of view range, then it will decide if the player is visible or if they are behind an obstacle, hence blocking the raycast.
                if (viewAngle > minDetectRadAngle && viewAngle < maxDetectRadAngle)
                {
                    Debug.Log("Player In Field Of View");

                    //creates a raycast between the player and the zombie to see if there is something blocking the raycast, which is the field of view for the zombie
                    
                    RaycastHit hit;
                    Vector3 playerStartPoint = new Vector3(player.transform.position.x, characterHeight, player.transform.position.z);
                    Vector3 zombieStartPoint = new Vector3(transform.position.x, characterHeight, transform.position.z);
                    //raycast for visual demonstration purposes
                    Debug.DrawLine(playerStartPoint, zombieStartPoint, Color.yellow);

                    //check for obstructions
                    if (Physics.Linecast(playerStartPoint, zombieStartPoint, out hit, ignoreSelfCollider))
                    {
                        //cannot find the target since there is an object blocking the view
                        Debug.Log("There is an obstacle in the way");
                    }
                    else
                    {
                        Debug.Log("Target Found");
                        zombManager.currentTarget = player;
                    }
                    
                }
            }
        }
    }
}
