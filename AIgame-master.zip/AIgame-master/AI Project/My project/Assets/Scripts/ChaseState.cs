using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChaseState : State
{
    AttackState attackState;
    

    private void Awake()
    {
        attackState = GetComponent<AttackState>();
    }
    public override State Tick(ZombManager zombManager)
    {
        Debug.Log("Moved to chase state");
        MoveToTarget(zombManager);
        rotateToTarget(zombManager);

        //if the player is within the minimum attack distance then it call the attackstate function.
        if (zombManager.DistFromTarget <= zombManager.minAttackDist)
        {
            return attackState;
        }
        //if not , it will keep chasing the target
        else
        {
            return this;
        }

    }

      
    //sets the animation variable to 1 in the blend tree which is the chase animation
    private void MoveToTarget(ZombManager zombManager)
    {
        //added time.deltatime for a smoother transition
        zombManager.animator.SetFloat("Animation", 1, 0.2f, Time.deltaTime);

    }
    //allows the zombie to be able to rotate to the player rather than walking in a straight line
    private void rotateToTarget(ZombManager zombManager)
    {
        zombManager.zombNMAgent.enabled = true;
        zombManager.zombNMAgent.SetDestination(zombManager.currentTarget.transform.position);
        zombManager.transform.rotation = Quaternion.Slerp(zombManager.transform.rotation, zombManager.zombNMAgent.transform.rotation, zombManager.rotationSpeed / Time.deltaTime);

    }
}
