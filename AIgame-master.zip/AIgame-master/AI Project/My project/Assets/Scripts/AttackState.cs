using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackState : State
{
    ChaseState chaseState;

    private void Awake()
    {
        chaseState = GetComponent<ChaseState>();
    }
    public override State Tick(ZombManager zombManager)
    {
        Debug.Log("Moved to attack state");
        MoveToAttackState(zombManager); 
       
        //if the player moves away from the minimum attack distance then it will go back to the chase animation
        if (zombManager.DistFromTarget >= zombManager.minAttackDist)
        {
            return chaseState;
        }
        //if closer then it will do the attack animation
        else
        {
            return this;
        }
        
  
    }

    //changes the animation variable to 2 in the blend tree and changes the animation to attack
    private void MoveToAttackState(ZombManager zombManager)
    {
        //added time.deltatime for a smoother transition
        zombManager.animator.SetFloat("Animation", 2, 0.2f, Time.deltaTime);
    }



}
